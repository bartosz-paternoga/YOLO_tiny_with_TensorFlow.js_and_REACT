This is a REACT app with TensorFlow.js and YOLO tiny. The app is making an object prediction based on webcam feed.
LIVE DEMO: https://bartosz-paternoga.github.io/react-yolo-tfjs
